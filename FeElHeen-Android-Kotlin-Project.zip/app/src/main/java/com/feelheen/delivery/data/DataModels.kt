package com.feelheen.delivery.data

enum class OrderStatus(val titleAr: String, val stepIndex: Int) {
    RECEIVED("تم استلام الطلب", 1),
    PREPARING("جاري تحضير الوجبة", 2),
    DRIVER_ASSIGNED("تم تعيين المندوب", 3),
    ON_THE_WAY("المندوب في الطريق", 4),
    DELIVERED("تم التوصيل بنجاح", 5)
}

data class ProductOption(
    val id: String,
    val name: String,
    val price: Double
)

data class Product(
    val id: String,
    val storeId: String,
    val nameAr: String,
    val descriptionAr: String,
    val price: Double,
    val originalPrice: Double? = null,
    val category: String,
    val images: List<String>,
    val isPopular: Boolean = false,
    val options: List<ProductOption> = emptyList()
)

data class Store(
    val id: String,
    val nameAr: String,
    val category: String,
    val rating: Double,
    val reviewCount: Int,
    val deliveryTimeMin: Int,
    val deliveryTimeMax: Int,
    val deliveryFee: Double,
    val addressAr: String,
    val bannerImage: String,
    val isOpen: Boolean = true,
    val tagsAr: List<String> = emptyList()
)

data class CartItem(
    val product: Product,
    val quantity: Int,
    val selectedOptions: List<ProductOption> = emptyList(),
    val specialInstructions: String? = null
)

data class Order(
    val id: String,
    val orderNumber: String,
    val createdAt: String,
    val items: List<CartItem>,
    val subtotal: Double,
    val deliveryFee: Double,
    val total: Double,
    val status: OrderStatus,
    val customerName: String,
    val customerPhone: String,
    val customerAddress: String,
    val customerDistrict: String,
    val storeName: String,
    val driverName: String,
    val driverPhone: String,
    val driverScooter: String,
    val estimatedDeliveryMin: Int = 25
)
