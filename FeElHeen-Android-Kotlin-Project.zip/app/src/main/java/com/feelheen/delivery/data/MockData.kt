package com.feelheen.delivery.data

object MockData {
    val districts = listOf(
        "شارع القروان", "حي الوفاق", "حي القدس", "حي المسيرة", 
        "شارع السمارة", "ساحة المشور", "حي العودة", "حي 25 مارس"
    )

    val stores = listOf(
        Store(
            id = "andalous-snack",
            nameAr = "سناك الأندلس العيون",
            category = "fast_food",
            rating = 4.8,
            reviewCount = 142,
            deliveryTimeMin = 15,
            deliveryTimeMax = 25,
            deliveryFee = 7.0,
            addressAr = "شارع القروان، العيون",
            bannerImage = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&auto=format&fit=crop&q=80",
            isOpen = true,
            tagsAr = listOf("طاكوس", "برغر", "بانيني", "بيتزا")
        ),
        Store(
            id = "sakia-grill",
            nameAr = "مشواة الساقية الحمراء",
            category = "grills",
            rating = 4.9,
            reviewCount = 98,
            deliveryTimeMin = 25,
            deliveryTimeMax = 40,
            deliveryFee = 10.0,
            addressAr = "شارع السمارة قرب ساحة المشور، العيون",
            bannerImage = "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=600&auto=format&fit=crop&q=80",
            isOpen = true,
            tagsAr = listOf("مشاوي إبل", "طاجين", "شواء صحراوي")
        )
    )

    val products = listOf(
        Product(
            id = "tacos-xxl",
            storeId = "andalous-snack",
            nameAr = "طاكوس ملكي XXL بالصلصة الجزائرية",
            descriptionAr = "طاكوس ساخن محشو بشرائح الدجاج ولحم المفروم، بطاطس مقلية وصلصة الجبن الذائبة والصلصة الجزائرية الحارة.",
            price = 38.0,
            originalPrice = 45.0,
            category = "fast_food",
            images = listOf("https://images.unsplash.com/photo-1628840042765-356cda07504e?w=600&auto=format&fit=crop&q=80"),
            isPopular = true
        ),
        Product(
            id = "camel-grill-plate",
            storeId = "sakia-grill",
            nameAr = "شواء لحم الإبل الصحراوي الفاخر",
            descriptionAr = "قضبان لحم الإبل الطازج متبل بالأعشاب الصحراوية والكمون، يقدم مع خبز بلدي وبصل مشوي وشاي.",
            price = 65.0,
            category = "grills",
            images = listOf("https://images.unsplash.com/photo-1544025162-d76694265947?w=600&auto=format&fit=crop&q=80"),
            isPopular = true
        )
    )
}
