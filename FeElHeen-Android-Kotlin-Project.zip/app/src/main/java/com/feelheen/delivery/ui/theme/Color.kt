package com.feelheen.delivery.ui.theme
import androidx.compose.ui.graphics.Color

val OrangePrimary = Color(0xFFEA580C)
val OrangeLight = Color(0xFFF97316)
val OrangeDark = Color(0xFFC2410C)
val AmberAccent = Color(0xFFF59E0B)
val BackgroundDark = Color(0xFF0C0A09)
val SurfaceDark = Color(0xFF1C1917)
val CardBackground = Color(0xFF292524)
val TextWhite = Color(0xFFFAFAF9)
val TextMuted = Color(0xFFA8A29E)
